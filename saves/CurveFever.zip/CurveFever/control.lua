script.on_event(defines.events.on_chunk_generated, function (event)
    -- Fill all generated chunks with out-of-map tiles
    local surface = event.surface
    local area = event.area
    local tiles = { }
    for x = area.left_top.x, area.right_bottom.x do
        for y = area.left_top.y, area.right_bottom.y do
            if x ~= 0 or y ~= 0 then    -- Leave a spot for player to spawn on
                table.insert(tiles, {
                    name = "out-of-map",
                    position = {x, y},
                })
            end
        end
    end
    surface.set_tiles(tiles)
end)

remote.add_interface("world", {
    out_of_world_tile_generation = function(enable)
        if enable == nil then enable = true end
        script_data.generation.out_of_world_tile = enable
    end,

    chuck_generation = function(enable)
        local setting = 1
        if not enable or enable == false then
            setting = 0
        end
        local surface = game.get_surface(1)
        local settings = surface.map_gen_settings
        settings.width = setting
        settings.height = setting
        surface.map_gen_settings = settings
    end
})